# Mor Ink Soundtrack v1.0.0 (development build)

A branded Android studio soundtrack logger. This build incorporates Shazam notification capture, Pixel Now Playing support, on-device history, private HTTPS receiver settings, scheduled/location capture modes, visible upload diagnostics, and periodic pending-queue retries while the notification listener is connected.

## Setup
1. Install the APK and open **Set up song detection**. Enable Mor Ink Soundtrack in Android's Notification access settings.
2. Choose Always On, Scheduled, Location Only, or Off. Scheduled uses device local time. Location Only requires coordinates and location permission; it uses last-known location and a 250 m radius.
3. Enter the private HTTPS receiver URL and shared secret. Keep the secret private; do not put it in public website code.
4. Open **Sync health** to see pending queue count, last upload status, HTTP response code/body summary, and attempt time. Diagnostics never store the secret.

## Upload behavior
- Recognized songs are retained locally and assigned an event ID.
- Non-2xx responses and network exceptions are queued and shown in Sync health.
- The queue retries when notifications arrive, when the notification listener reconnects, and every 60 seconds while that service remains connected.
- A 2xx response means the receiver returned success; it does not independently prove the receiver saved the song. The Wix receiver should return a clear JSON success/error response and deduplicate by `eventId`.
- The app does not record or upload raw audio. It reads supported song-identification notifications after notification access is granted.

## Build status
This source ZIP has not been compiled in this environment. Build and device-test it with the repository's Android Gradle workflow before distributing it. Confirm the Wix receiver's accepted payload and response format before calling the integration production-ready.
