package com.morink.soundtrack

import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import java.time.LocalTime
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var history: TextView
    private lateinit var mode: Spinner
    private lateinit var startTime: EditText
    private lateinit var endTime: EditText
    private lateinit var weekdays: CheckBox
    private lateinit var override: CheckBox
    private lateinit var latitude: EditText
    private lateinit var longitude: EditText
    private lateinit var studio: EditText

    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF111110.toInt()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
            setBackgroundColor(0xFF111110.toInt())
        }
        scroll.addView(content)
        content.addView(label("M O R   I N K", 13, GOLD).apply { typeface = Typeface.DEFAULT_BOLD })
        content.addView(label("Shop Soundtrack", 30, IVORY).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
        content.addView(label("A quiet, reliable soundtrack bridge for your studio.", 14, MUTED))
        content.addView(space(16))
        status = label("Checking setup…", 16, IVORY)
        content.addView(status)
        content.addView(action("Set up song detection") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        content.addView(space(14))

        content.addView(section("Studio setup"))
        studio = field("Studio name", prefs.getString(KEY_STUDIO, "Mor Ink Shop").orEmpty())
        content.addView(studio)
        content.addView(label("Operating mode", 14, GOLD))
        mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Always On", "Scheduled", "Location Only", "Off"))
            setSelection(prefs.getInt(KEY_MODE, 1).coerceIn(0, 3))
        }
        content.addView(mode)
        content.addView(label("Schedule uses this device's local time. Select days and a daily time window.", 13, MUTED))
        startTime = field("Start time (HH:mm)", prefs.getString(KEY_START, "09:00").orEmpty())
        endTime = field("End time (HH:mm)", prefs.getString(KEY_END, "18:00").orEmpty())
        content.addView(startTime); content.addView(endTime)
        weekdays = CheckBox(this).apply {
            text = "Enable Monday–Friday (uncheck for every day)"
            setTextColor(IVORY); isChecked = prefs.getBoolean(KEY_WEEKDAYS, true)
        }
        content.addView(weekdays)
        content.addView(label("For Location Only, set the studio coordinates below and grant location access when Android asks. A 250 m radius is used.", 13, MUTED))
        latitude = field("Studio latitude", prefs.getString(KEY_LAT, "").orEmpty())
        longitude = field("Studio longitude", prefs.getString(KEY_LON, "").orEmpty())
        content.addView(latitude); content.addView(longitude)
        override = CheckBox(this).apply {
            text = "Manual override: keep capture on"
            setTextColor(IVORY); isChecked = prefs.getBoolean(KEY_OVERRIDE, false)
        }
        content.addView(override)
        content.addView(action("Save studio and schedule") {
            val start = startTime.text.toString().trim(); val end = endTime.text.toString().trim()
            if (!validTime(start) || !validTime(end)) {
                Toast.makeText(this, "Use 24-hour time, for example 09:00", Toast.LENGTH_LONG).show(); return@action
            }
            val lat = latitude.text.toString().trim(); val lon = longitude.text.toString().trim()
            if (lat.isNotEmpty() && (lat.toDoubleOrNull()?.let { it !in -90.0..90.0 } != false)) { toast("Latitude must be between -90 and 90"); return@action }
            if (lon.isNotEmpty() && (lon.toDoubleOrNull()?.let { it !in -180.0..180.0 } != false)) { toast("Longitude must be between -180 and 180"); return@action }
            prefs.edit().putString(KEY_STUDIO, studio.text.toString().trim().ifBlank { "My Studio" })
                .putInt(KEY_MODE, mode.selectedItemPosition).putString(KEY_START, start).putString(KEY_END, end)
                .putBoolean(KEY_WEEKDAYS, weekdays.isChecked).putBoolean(KEY_OVERRIDE, override.isChecked)
                .putString(KEY_LAT, lat).putString(KEY_LON, lon).apply()
            if (mode.selectedItemPosition == 2 && android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 214)
            }
            refresh(); toast("Studio settings saved")
        })

        content.addView(space(18)); content.addView(section("Website connection"))
        content.addView(label("Add your private receiver URL and shared secret. They stay on this device. Never put the secret in public website code.", 13, MUTED))
        val endpoint = field("HTTPS receiver URL", prefs.getString(KEY_ENDPOINT, "").orEmpty())
        val secret = field("Receiver secret", prefs.getString(KEY_SECRET, "").orEmpty())
        content.addView(endpoint); content.addView(secret)
        content.addView(action("Save connection") {
            val url = endpoint.text.toString().trim()
            if (url.isNotEmpty() && !url.startsWith("https://", true)) { toast("Use a secure HTTPS receiver URL"); return@action }
            prefs.edit().putString(KEY_ENDPOINT, url).putString(KEY_SECRET, secret.text.toString()).apply()
            toast("Connection saved. Pending events retry when a new song notification arrives.")
        })

        content.addView(space(18)); content.addView(section("Recent songs"))
        history = label("", 14, IVORY); content.addView(history)
        content.addView(action("Check setup") { refresh() })
        content.addView(space(18)); content.addView(section("Need a hand?"))
        content.addView(label("Song detection reads supported music-identification notifications after you grant access. It does not use the microphone. Pixel Now Playing notifications can vary by Android version.", 13, MUTED))
        content.addView(action("Copy safe AI setup prompt") {
            val prompt = "Help me set up a shop soundtrack website receiver. First ask which website platform I use, then give platform-specific steps. Never ask me for passwords, API keys, access tokens, or my receiver secret. Explain how to keep the receiver secret private."
            val clip = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clip.setPrimaryClip(android.content.ClipData.newPlainText("Mor Ink setup prompt", prompt)); toast("Prompt copied")
        })
        setContentView(scroll)
        refresh()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refresh() }

    private fun refresh() {
        val allowed = (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .isNotificationListenerAccessGranted(ComponentName(this, NowPlayingListener::class.java))
        val modeName = listOf("Always On", "Scheduled", "Location Only", "Off")[prefs.getInt(KEY_MODE, 1).coerceIn(0, 3)]
        status.text = "${if (allowed) "● Detection access granted" else "○ Detection access needed"}\n${prefs.getString(KEY_STUDIO, "Mor Ink Shop")} · $modeName · ${if (captureAllowed(this)) "Capture active" else "Capture paused"}"
        val arr = try { org.json.JSONArray(prefs.getString(KEY_HISTORY, "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        history.text = if (arr.length() == 0) "No songs captured yet" else (maxOf(0, arr.length() - 8) until arr.length()).reversed().joinToString("\n\n") { i ->
            val item = arr.optJSONObject(i); "${item?.optString("title")} — ${item?.optString("artist")}\n${item?.optString("playedAt")}"
        }
    }

    private fun field(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); setSingleLine(true); textSize = 15f
        setTextColor(IVORY); setHintTextColor(0xFF77746D.toInt()); setPadding(12, 8, 12, 8)
    }
    private fun label(text: String, size: Int, color: Int) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); setPadding(0, 6, 0, 6) }
    private fun section(text: String) = label(text, 19, IVORY).apply { typeface = Typeface.DEFAULT_BOLD }
    private fun space(height: Int) = TextView(this).apply { this.height = height }
    private fun action(text: String, run: () -> Unit) = Button(this).apply { this.text = text; setOnClickListener { run() } }
    private fun validTime(value: String) = try { LocalTime.parse(value); true } catch (_: Exception) { false }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    companion object {
        const val PREFS = "mor_ink_soundtrack"
        const val KEY_HISTORY = "song_history"; const val KEY_ENDPOINT = "endpoint"; const val KEY_SECRET = "secret"
        const val KEY_LAST_SONG = "last_song"; const val KEY_LAST_KEY = "last_key"
        const val KEY_MODE = "capture_mode"; const val KEY_START = "schedule_start"; const val KEY_END = "schedule_end"
        const val KEY_WEEKDAYS = "schedule_weekdays"; const val KEY_OVERRIDE = "manual_override"
        const val KEY_LAT = "studio_latitude"; const val KEY_LON = "studio_longitude"; const val KEY_STUDIO = "studio_name"
        private const val GOLD = 0xFFD7C6A1.toInt(); private const val IVORY = 0xFFF2EFE8.toInt(); private const val MUTED = 0xFFAAA69D.toInt()

        fun captureAllowed(context: Context): Boolean {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (p.getBoolean(KEY_OVERRIDE, false)) return true
            return when (p.getInt(KEY_MODE, 1)) {
                0 -> true
                1 -> {
                    val cal = Calendar.getInstance(); val day = cal.get(Calendar.DAY_OF_WEEK)
                    if (p.getBoolean(KEY_WEEKDAYS, true) && day !in Calendar.MONDAY..Calendar.FRIDAY) return false
                    val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                    val start = try { LocalTime.parse(p.getString(KEY_START, "09:00")).toSecondOfDay() / 60 } catch (_: Exception) { 540 }
                    val end = try { LocalTime.parse(p.getString(KEY_END, "18:00")).toSecondOfDay() / 60 } catch (_: Exception) { 1080 }
                    if (start <= end) now in start until end else now >= start || now < end
                }
                2 -> {
                    val lat = p.getString(KEY_LAT, "")?.toDoubleOrNull() ?: return false
                    val lon = p.getString(KEY_LON, "")?.toDoubleOrNull() ?: return false
                    try {
                        val lm = context.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
                        val location = listOf(android.location.LocationManager.NETWORK_PROVIDER, android.location.LocationManager.GPS_PROVIDER)
                            .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null } }
                            .minByOrNull { it.distanceTo(android.location.Location("studio").apply { latitude = lat; longitude = lon }) } ?: return false
                        location.distanceTo(android.location.Location("studio").apply { latitude = lat; longitude = lon }) <= 250f
                    } catch (_: SecurityException) { false }
                }
                else -> false
            }
        }
    }
}
