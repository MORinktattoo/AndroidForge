# Mor Ink Soundtrack for Google Pixel — Android prototype

A native Android/Kotlin starter app for the Shop Soundtrack project. It requests Android Notification Listener access, looks for song-identification/media notifications, parses title/artist, and can POST events to the future Wix receiver.

## Current status
- Source project is included; no APK has been built or tested on a Pixel yet.
- Wix receiver is not configured. The app needs a receiver URL and shared secret entered in Settings after the Wix backend is deployed.
- Pixel Now Playing notification format/package varies by Android version. This is a prototype and must be tested on the actual phone. If Now Playing does not expose a usable notification, this approach will not capture tracks automatically and we must change the detection method.
- Failed sends are held in a local queue and retried when the notification listener reconnects or another notification arrives. This is a prototype queue, not a hardened database.
- The app does not record microphone audio. It reads notification fields only after the user grants notification access.

## Build an installable APK
Open this folder in Android Studio (current stable), allow Gradle sync, and build `app` → `Build APK(s)`. Install the debug APK on the Pixel for testing. `compileSdk 35` is configured; Android Studio may prompt to install that SDK platform.

## First test sequence
1. Install the debug APK.
2. Open Mor Ink Soundtrack and tap **Enable notification access**; enable it in Android settings.
3. Enable Pixel Settings → Now Playing and notifications.
4. Play a known song and verify a media/Now Playing notification appears.
5. Return to the app and check the last event. It will only sync once Wix receiver URL and secret are configured.

## Privacy and security
Notification access is sensitive: Android can expose notifications from other apps. The prototype filters for likely music notifications but that filter is not a security boundary. Only enable access on the shop's dedicated Pixel, and review what the app captures before using it. Keep the receiver secret private; never place it in the public website frontend.
