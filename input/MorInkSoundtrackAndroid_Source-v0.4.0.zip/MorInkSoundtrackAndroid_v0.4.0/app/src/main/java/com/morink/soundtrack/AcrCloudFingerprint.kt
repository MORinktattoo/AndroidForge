package com.morink.soundtrack

import com.acrcloud.rec.ACRCloudClient
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Converts one in-memory PCM window to ACRCloud's compact fingerprint format. */
internal object AcrCloudFingerprint {
    fun create(pcm: ByteArray, sampleRate: Int): ByteArray? {
        if (pcm.isEmpty() || pcm.size % 2 != 0) return null
        val wav = ByteArray(44 + pcm.size)
        val header = ByteBuffer.wrap(wav).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + pcm.size)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1) // PCM
        header.putShort(1) // mono
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)
        header.putShort(2)
        header.putShort(16)
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcm.size)
        System.arraycopy(pcm, 0, wav, 44, pcm.size)
        return try {
            ACRCloudClient.createClientFingerprint(wav, wav.size, sampleRate, 1)
        } finally {
            wav.fill(0)
        }
    }
}
