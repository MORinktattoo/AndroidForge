# Mor Ink Shop Soundtrack 0.2.0

Android helper that reads supported song identification notifications after notification access is explicitly granted, keeps recent events on-device, and sends them to a private HTTPS receiver.

## Setup
1. Install the APK and open **Set up song detection**. Enable Mor Ink Soundtrack in Android's Notification access settings.
2. Choose Always On, Scheduled, Location Only, or Off. Scheduled uses the device's local time. Location Only needs studio coordinates and Android location permission; it uses the last known location and a 250 m radius.
3. Add the private HTTPS receiver URL and shared secret. Keep the secret private; do not put it in public HTML.
4. Keep the app's notification access enabled. Pending events are retained locally and retried when the listener reconnects or a later notification arrives.

The app does not record microphone audio. Android may limit background location updates; Location Only evaluates the device's last known location when a supported song notification arrives. Test this behavior at the studio before relying on it.

A copy-ready safe prompt for an AI setup helper is included in the app. It does not contain account credentials or receiver secrets. Wix receiver implementation and multi-studio website routing must be configured on the website side.
