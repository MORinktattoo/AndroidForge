package com.morink.soundtrack

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.Executors

class NowPlayingListener : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onListenerConnected() {
        super.onListenerConnected()
        executor.execute { flushQueue() }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        executor.execute { flushQueue() }
        if (!MainActivity.captureAllowed(this)) return
        val extras = sbn.notification.extras ?: return
        val packageName = sbn.packageName.lowercase(Locale.ROOT)
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val combined = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString(" — ")

        // Intentionally conservative: only inspect likely music / system Now Playing notifications.
        // Exact Pixel package/text varies by Android version and must be verified during device testing.
        val looksLikeMusic = packageName == "com.google.intelligence.sense" || packageName == "com.google.android.as" ||
            packageName.contains("ambient") || packageName.contains("music") ||
            packageName.contains("google") && (combined.contains("now playing", true) || combined.contains("identified", true)) ||
            combined.contains("now playing", true)
        if (!looksLikeMusic || title.isBlank() || combined.length < 3) return

        val pair = parseSong(title, text, bigText) ?: return
        val playedAt = Instant.ofEpochMilli(sbn.postTime).toString()
        val key = "${pair.first.lowercase(Locale.ROOT)}|${pair.second.lowercase(Locale.ROOT)}"
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val lastAt = prefs.getLong("last_song_seen_at", 0L)
        if (prefs.getString(MainActivity.KEY_LAST_KEY, "") == key && sbn.postTime - lastAt < 120_000L) return
        prefs.edit().putString(MainActivity.KEY_LAST_KEY, key)
            .putLong("last_song_seen_at", sbn.postTime)
            .putString(MainActivity.KEY_LAST_SONG, "${pair.first} — ${pair.second} · waiting to sync")
            .apply()

        val payload = JSONObject().put("title", pair.first).put("artist", pair.second)
            .put("playedAt", playedAt).put("eventId", "${sbn.postTime}-${key.hashCode()}")
            .put("studio", prefs.getString(MainActivity.KEY_STUDIO, "Mor Ink Shop"))
            .put("source", "pixel-notification-listener")
        synchronized(this) {
            val h = try { org.json.JSONArray(prefs.getString(MainActivity.KEY_HISTORY, "[]") ?: "[]") } catch (e: Exception) { org.json.JSONArray() }
            h.put(JSONObject(payload.toString()))
            val trimmed = org.json.JSONArray()
            for (i in maxOf(0, h.length() - 2000) until h.length()) trimmed.put(h.get(i))
            prefs.edit().putString(MainActivity.KEY_HISTORY, trimmed.toString()).apply()
        }
        executor.execute { sendOrQueue(payload) }
    }

    private fun parseSong(title: String, text: String, bigText: String): Pair<String, String>? {
        val candidates = listOf(text, bigText, title).map { it.trim() }.filter { it.isNotBlank() }
        for (candidate in candidates) {
            val separators = listOf(" — ", " - ", " • ", " by ")
            for (separator in separators) {
                if (candidate.contains(separator)) {
                    val parts = candidate.split(separator, limit = 2).map { it.trim() }
                    if (parts.size == 2 && parts.all { it.isNotBlank() } && parts.none { it.length > 120 }) {
                        return parts[0] to parts[1]
                    }
                }
            }
        }
        // Common Android media-notification shape: title is the track and text is the artist.
        if (title.isNotBlank() && text.isNotBlank() &&
            !title.contains("now playing", true) && !text.contains("now playing", true) &&
            title != text && title.length <= 120 && text.length <= 120) {
            return title to text
        }
        // Do not guess an artist if notification format does not provide one.
        return null
    }

    private fun sendOrQueue(payload: JSONObject) {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val endpoint = prefs.getString(MainActivity.KEY_ENDPOINT, "").orEmpty()
        val secret = prefs.getString(MainActivity.KEY_SECRET, "").orEmpty()
        if (endpoint.isBlank() || secret.isBlank()) {
            appendQueue(payload)
            return
        }
        try {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-shop-secret", secret)
            }
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            connection.disconnect()
            if (code !in 200..299) appendQueue(payload)
            else prefs.edit().putString(MainActivity.KEY_LAST_SONG,
                "${payload.optString("title")} — ${payload.optString("artist")} · synced").apply()
        } catch (_: Exception) { appendQueue(payload) }
    }

    private fun flushQueue() {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val endpoint = prefs.getString(MainActivity.KEY_ENDPOINT, "").orEmpty()
        val secret = prefs.getString(MainActivity.KEY_SECRET, "").orEmpty()
        if (endpoint.isBlank() || secret.isBlank()) return
        val oldQueue = org.json.JSONArray(prefs.getString("pending_queue", "[]"))
        if (oldQueue.length() == 0) return
        val remaining = org.json.JSONArray()
        for (i in 0 until oldQueue.length()) {
            val item = oldQueue.optJSONObject(i) ?: continue
            if (!postPayload(endpoint, secret, item)) remaining.put(item)
        }
        prefs.edit().putString("pending_queue", remaining.toString()).apply()
    }

    private fun postPayload(endpoint: String, secret: String, payload: JSONObject): Boolean {
        return try {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 8000; readTimeout = 8000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-shop-secret", secret)
            }
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            connection.disconnect()
            code in 200..299
        } catch (_: Exception) { false }
    }

    private fun appendQueue(payload: JSONObject) {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        synchronized(this) {
            val queue = org.json.JSONArray(prefs.getString("pending_queue", "[]"))
            val id = payload.optString("eventId")
            val alreadyQueued = (0 until queue.length()).any { queue.optJSONObject(it)?.optString("eventId") == id }
            if (!alreadyQueued && queue.length() < 3000) queue.put(payload)
            prefs.edit().putString("pending_queue", queue.toString())
                .putString(MainActivity.KEY_LAST_SONG,
                    "${payload.optString("title")} — ${payload.optString("artist")} · queued").apply()
        }
    }
}
