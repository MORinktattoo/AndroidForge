package com.morink.soundtrack

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

/** Stores song metadata locally and retries Wix delivery; audio and audio signatures are never stored. */
internal object SongEventLogger {
    private val executor = Executors.newSingleThreadExecutor()
    private val lock = Any()

    fun record(context: Context, title: String, artist: String, source: String) {
        val cleanTitle = title.trim().take(160)
        val cleanArtist = artist.trim().take(160)
        if (cleanTitle.isBlank() || cleanArtist.isBlank()) return
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val key = "${cleanTitle.lowercase(Locale.ROOT)}|${cleanArtist.lowercase(Locale.ROOT)}"
        val now = System.currentTimeMillis()
        synchronized(lock) {
            if (prefs.getString(MainActivity.KEY_LAST_KEY, "") == key &&
                now - prefs.getLong("last_song_seen_at", 0L) < DEDUPE_MS) return
            prefs.edit().putString(MainActivity.KEY_LAST_KEY, key).putLong("last_song_seen_at", now).apply()

            val deviceId = prefs.getString(DEVICE_ID_PREF, null) ?: UUID.randomUUID().toString().also {
                prefs.edit().putString(DEVICE_ID_PREF, it).apply()
            }
            val event = JSONObject()
                .put("title", cleanTitle)
                .put("artist", cleanArtist)
                .put("playedAt", Instant.ofEpochMilli(now).toString())
                .put("eventId", UUID.randomUUID().toString())
                .put("deviceId", deviceId)
                .put("studio", prefs.getString(MainActivity.KEY_STUDIO, "Mor Ink Shop"))
                .put("source", source)

            val history = jsonArray(prefs.getString(MainActivity.KEY_HISTORY, "[]"))
            history.put(JSONObject(event.toString()))
            val trimmed = JSONArray()
            for (i in maxOf(0, history.length() - 2000) until history.length()) trimmed.put(history.get(i))
            prefs.edit().putString(MainActivity.KEY_HISTORY, trimmed.toString()).apply()
            enqueueOrSend(app, event)
        }
    }

    fun flush(context: Context) {
        val app = context.applicationContext
        executor.execute {
            val prefs = app.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
            val endpoint = prefs.getString(MainActivity.KEY_ENDPOINT, "").orEmpty()
            val secret = prefs.getString(MainActivity.KEY_SECRET, "").orEmpty()
            if (!endpoint.startsWith("https://", true) || secret.isBlank()) return@execute
            val queue = jsonArray(prefs.getString(QUEUE_KEY, "[]"))
            val remaining = JSONArray()
            for (i in 0 until queue.length()) {
                val event = queue.optJSONObject(i) ?: continue
                if (!post(endpoint, secret, event)) remaining.put(event)
            }
            prefs.edit().putString(QUEUE_KEY, remaining.toString()).apply()
        }
    }

    private fun enqueueOrSend(context: Context, event: JSONObject) {
        executor.execute {
            val prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
            val endpoint = prefs.getString(MainActivity.KEY_ENDPOINT, "").orEmpty()
            val secret = prefs.getString(MainActivity.KEY_SECRET, "").orEmpty()
            if (endpoint.startsWith("https://", true) && secret.isNotBlank() && post(endpoint, secret, event)) {
                prefs.edit().putString(MainActivity.KEY_LAST_SONG,
                    "${event.optString("title")} — ${event.optString("artist")} · synced").apply()
                return@execute
            }
            synchronized(lock) {
                val queue = jsonArray(prefs.getString(QUEUE_KEY, "[]"))
                if (queue.length() < 3000) queue.put(event)
                prefs.edit().putString(QUEUE_KEY, queue.toString())
                    .putString(MainActivity.KEY_LAST_SONG,
                        "${event.optString("title")} — ${event.optString("artist")} · queued").apply()
            }
        }
    }

    private fun post(endpoint: String, secret: String, event: JSONObject): Boolean = try {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 10000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-shop-secret", secret)
        }
        try {
            connection.outputStream.use { it.write(event.toString().toByteArray(Charsets.UTF_8)) }
            connection.responseCode in 200..299
        } finally { connection.disconnect() }
    } catch (_: Exception) { false }

    private fun jsonArray(raw: String?): JSONArray = try { JSONArray(raw ?: "[]") } catch (_: Exception) { JSONArray() }
    private const val QUEUE_KEY = "pending_queue"
    private const val DEDUPE_MS = 600_000L
}
