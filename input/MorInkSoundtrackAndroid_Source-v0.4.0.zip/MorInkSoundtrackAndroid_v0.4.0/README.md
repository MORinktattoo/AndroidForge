# Mor Ink Shop Soundtrack 0.4.0

Android studio soundtrack logger for Pixel and Samsung phones. It retains the existing Pixel/Samsung Now Playing notification listener as a fallback and adds continuous ACRCloud matching through a Wix relay.

## Recognition and privacy

- The app captures 12 seconds of 48 kHz mono PCM at a time in memory and creates an ACRCloud fingerprint on the phone.
- It clears the PCM and WAV buffers after fingerprinting. It does not write audio or fingerprints to storage.
- It checks a 12-second window once per minute and sends only the fingerprint to the configured Wix HTTPS endpoint. The microphone recorder is released between windows and while the studio schedule is off. Wix forwards that fingerprint to ACRCloud. ACRCloud may retain fingerprints and recognition results under its service terms.
- The app shows a disclosure and requires the phone user to confirm before first microphone recognition.
- Wix credentials stay in Wix Secrets Manager. The Android app contains only the existing shop receiver secret, which is required by the preserved `x-shop-secret` contract and can be extracted from an APK.
- Recognized song details continue to use the existing Wix receiver. The app keeps a local metadata queue and retries failed song log deliveries.
- Event IDs and stable per-installation device IDs let the shared Wix history accept multiple phones.

## Wix configuration

Add the `post_recognize` handler from the companion `wix-acrcloud/http-functions.js` snippet to the existing Wix `src/backend/http-functions.js`. Keep the existing `post_song`, public soundtrack page, and GET routes unchanged. The recognition handler checks the same `SHOP_SONG_SECRET` header, reads ACRCloud credentials only from Wix Secrets Manager, and returns `{ "status": "matched", "title": "…", "artist": "…" }` or `{ "status": "no_match" }`.

Add these Wix secrets after creating an ACRCloud music-recognition project:

- `ACRCLOUD_HOST`: the exact identify host shown for the project, without `https://` or a path.
- `ACRCLOUD_ACCESS_KEY`: the project access key.
- `ACRCLOUD_ACCESS_SECRET`: the project access secret.

Use the existing `SHOP_SONG_SECRET`; do not create a second shop secret. The Android fingerprint endpoint is `https://www.mortattoo.com/_functions/recognize` once the Wix code is published. Keep the current song receiver configured separately in the app.

## Install and use

1. Add and publish the Wix handler, then place the three ACRCloud project values in Wix Secrets Manager.
2. Build this versioned source archive through the existing AndroidForge **Build Android APK** workflow.
3. Install the generated APK on each studio phone.
4. Enter the existing Wix song receiver URL, the existing shared receiver secret, and the Wix fingerprint endpoint in **Website connection**.
5. Choose the studio schedule and operating mode. Tap **Enable automatic studio recognition** and confirm the fingerprint disclosure once. Android will request microphone and notification access and keep an ongoing notification while recognition runs.
6. Use **Stop studio recognition** to stop the foreground service and disable automatic starts. The service waits through off-hours after you enable it, then resumes scheduled checks while it remains running.

Recognition checks a 12-second window once per minute. Enable the service once while the app is open and keep the foreground notification active. Android may stop a service after a device restart or restrict starting it while the app is closed; reopen the app to restart it. Test screen-off operation and matching on both Pixel and Samsung before relying on it for a full studio day. Recognition results depend on the trial/project quota and ACRCloud catalog matches.

## Source archive

The ACRCloud Android SDK binaries are from the vendor's public `acrcloud/ACRCloudUniversalSDK` repository, release `1.3.33`. This archive includes the Java SDK and Android native engine libraries for arm64-v8a, armeabi-v7a, x86, and x86_64. No ACRCloud project keys or Wix credentials are included.
