package com.morink.soundtrack

/** Shared preference keys used by the activity, recognition service, and song logger. */
internal const val FINGERPRINT_ENDPOINT_PREF = "acrcloud_fingerprint_endpoint"
internal const val DEVICE_ID_PREF = "device_id"
