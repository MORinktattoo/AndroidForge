package com.morink.soundtrack

import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var endpoint: EditText
    private lateinit var secret: EditText
    private lateinit var status: TextView
    private lateinit var lastSong: TextView
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF111110.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("MOR INK", 13, 0xFFD7C6A1.toInt()))
        content.addView(label("Shop Soundtrack", 30, 0xFFF2EFE8.toInt()))
        content.addView(label("Song capture hub · prototype", 15, 0xFFAAA69D.toInt()))
        content.addView(space(24))

        status = label("Status: checking notification access…", 16, 0xFFF2EFE8.toInt())
        content.addView(status)
        content.addView(Button(this).apply {
            text = "Enable notification access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        content.addView(space(16))

        content.addView(label("Wix receiver URL", 14, 0xFFD7C6A1.toInt()))
        endpoint = EditText(this).apply {
            hint = "https://your-domain/_functions/song"
            setSingleLine(true)
            setText(prefs.getString(KEY_ENDPOINT, "") ?: "")
            setTextColor(0xFFF2EFE8.toInt()); setHintTextColor(0xFF77746D.toInt())
        }
        content.addView(endpoint, matchWrap())

        content.addView(label("Receiver secret", 14, 0xFFD7C6A1.toInt()))
        secret = EditText(this).apply {
            hint = "Add after Wix receiver is configured"
            setSingleLine(true)
            setText(prefs.getString(KEY_SECRET, "") ?: "")
            setTextColor(0xFFF2EFE8.toInt()); setHintTextColor(0xFF77746D.toInt())
        }
        content.addView(secret, matchWrap())

        content.addView(Button(this).apply {
            text = "Save connection settings"
            setOnClickListener {
                prefs.edit().putString(KEY_ENDPOINT, endpoint.text.toString().trim())
                    .putString(KEY_SECRET, secret.text.toString()).apply()
                Toast.makeText(this@MainActivity, "Settings saved on this device", Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        })
        content.addView(space(20))
        content.addView(label("Last song event", 14, 0xFFD7C6A1.toInt()))
        lastSong = label(prefs.getString(KEY_LAST_SONG, "No song captured yet") ?: "No song captured yet", 16, 0xFFF2EFE8.toInt())
        content.addView(lastSong)
        content.addView(space(16))
        content.addView(label("Recent songs (newest first)", 14, 0xFFD7C6A1.toInt()))
        history = label(historyText(prefs), 15, 0xFFF2EFE8.toInt())
        content.addView(history)
        content.addView(space(16))
        content.addView(label("How it works", 18, 0xFFF2EFE8.toInt()))
        content.addView(label("This app watches notifications you explicitly allow it to access and looks for music-identification notifications. It does not listen to microphone audio or run its own song-recognition engine. Pixel Now Playing compatibility must be verified on your device.", 14, 0xFFAAA69D.toInt()))
        content.addView(space(12))
        content.addView(label("Connection is not active until the Wix receiver URL and secret are configured. Keep the secret private.", 13, 0xFFD7C6A1.toInt()))

        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars())
                v.setPadding(28, 28 + bars.top, 28, 28 + bars.bottom)
                insets
            }
        }
        refreshStatus()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }

    private fun refreshStatus() {
        val enabled = isNotificationAccessEnabled()
        status.text = if (enabled) "Status: notification access enabled" else "Status: notification access not enabled"
        if (::lastSong.isInitialized) {
            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            lastSong.text = prefs.getString(KEY_LAST_SONG, "No song captured yet") ?: "No song captured yet"
            history.text = historyText(prefs)
        }
    }

    private fun historyText(prefs: android.content.SharedPreferences): String {
        val arr = try { org.json.JSONArray(prefs.getString(KEY_HISTORY, "[]") ?: "[]") } catch (e: Exception) { org.json.JSONArray() }
        if (arr.length() == 0) return "No songs yet"
        val fmt = java.time.format.DateTimeFormatter.ofPattern("EEE MMM d · h:mm a", java.util.Locale.getDefault())
            .withZone(java.time.ZoneId.systemDefault())
        val sb = StringBuilder()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            val time = try { fmt.format(java.time.Instant.parse(o.optString("playedAt"))) } catch (e: Exception) { "" }
            sb.append(o.optString("title")).append(" — ").append(o.optString("artist")).append("\n")
            sb.append(time).append("\n\n")
        }
        return sb.toString().trim()
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return manager.isNotificationListenerAccessGranted(ComponentName(this, NowPlayingListener::class.java))
    }

    private fun label(text: String, size: Int, color: Int) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        setPadding(0, 6, 0, 6)
    }
    private fun space(h: Int) = TextView(this).apply { height = h }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    companion object {
        const val PREFS = "mor_ink_soundtrack"
        const val KEY_HISTORY = "song_history"
        const val KEY_ENDPOINT = "endpoint"
        const val KEY_SECRET = "secret"
        const val KEY_LAST_SONG = "last_song"
        const val KEY_LAST_KEY = "last_key"
    }
}
