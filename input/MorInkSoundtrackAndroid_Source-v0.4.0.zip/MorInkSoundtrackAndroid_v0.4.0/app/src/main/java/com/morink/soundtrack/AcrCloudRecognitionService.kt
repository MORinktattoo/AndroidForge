package com.morink.soundtrack

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.Process
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/** Captures short PCM windows in memory; only ACRCloud fingerprints leave this device. */
class AcrCloudRecognitionService : Service() {
    private val running = AtomicBoolean(false)
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var worker: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRecognition()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running.get()) startRecognition()
        return START_NOT_STICKY
    }

    private fun startRecognition() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return
        }
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        running.set(true)
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, true).apply()
        SongEventLogger.flush(this)
        worker = Thread({ recognitionLoop() }, "MorInk-ACRCloud-Audio").also { it.start() }
    }

    private fun recognitionLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sampleRate = 48000
        val pcmBytesPerWindow = sampleRate * 2 * WINDOW_SECONDS
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) { fail("Microphone is unavailable"); return }
        val recorderBufferSize = maxOf(minBuffer * 2, sampleRate)

        try {
            while (running.get()) {
                if (!MainActivity.captureAllowed(this)) {
                    Thread.sleep(SCHEDULE_CHECK_MS)
                    continue
                }

                val format = AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
                val audio = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(recorderBufferSize)
                    .build()
                recorder = audio
                audio.startRecording()
                val pcm = ByteArray(pcmBytesPerWindow)
                var offset = 0
                try {
                    while (running.get() && MainActivity.captureAllowed(this) && offset < pcm.size) {
                        val count = audio.read(pcm, offset, pcm.size - offset, AudioRecord.READ_BLOCKING)
                        if (count > 0) offset += count
                        else if (count < 0) throw IllegalStateException("Microphone read failed ($count)")
                    }
                } finally {
                    try { audio.stop() } catch (_: Exception) {}
                    audio.release()
                    recorder = null
                }
                if (!running.get()) {
                    pcm.fill(0)
                    break
                }
                if (offset != pcm.size) {
                    pcm.fill(0)
                    continue
                }

                val fingerprint = try { AcrCloudFingerprint.create(pcm, sampleRate) }
                finally { pcm.fill(0) }
                if (fingerprint != null && fingerprint.isNotEmpty() && MainActivity.captureAllowed(this)) {
                    try {
                        recognizeFingerprint(fingerprint)?.let { (title, artist) ->
                            SongEventLogger.record(this, title, artist, "acrcloud-microphone")
                        }
                    } finally {
                        fingerprint.fill(0)
                    }
                }
                if (running.get()) Thread.sleep(POLL_INTERVAL_MS)
            }
        } catch (error: Exception) {
            if (running.get()) fail(error.message?.take(160) ?: "Recognition stopped")
        } finally {
            recorder?.let { audio -> try { audio.stop() } catch (_: Exception) {}; audio.release() }
            recorder = null
        }
    }

    private fun recognizeFingerprint(fingerprint: ByteArray): Pair<String, String>? {
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val endpoint = prefs.getString(FINGERPRINT_ENDPOINT_PREF, "").orEmpty().trim()
        val secret = prefs.getString(MainActivity.KEY_SECRET, "").orEmpty()
        require(endpoint.startsWith("https://", ignoreCase = true)) {
            "Set the HTTPS Wix fingerprint endpoint in Website connection settings."
        }
        require(secret.isNotBlank()) { "Set the existing Wix receiver secret first." }

        val deviceId = prefs.getString(DEVICE_ID_PREF, null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString(DEVICE_ID_PREF, it).apply()
        }
        val encoded = android.util.Base64.encodeToString(fingerprint, android.util.Base64.NO_WRAP)
        val payload = JSONObject()
            .put("fingerprint", encoded)
            .put("deviceId", deviceId)
            .put("observedAt", Instant.now().toString())
        val body = payload.toString().toByteArray(Charsets.UTF_8)
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("x-shop-secret", secret)
        }
        return try {
            connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("Wix recognition endpoint returned HTTP $code")
            val response = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val json = JSONObject(response)
            val title = json.optString("title").trim()
            val artist = json.optString("artist").trim()
            if (json.optString("status") == "matched" && title.isNotBlank() && artist.isNotBlank()) title to artist else null
        } finally {
            body.fill(0)
            connection.disconnect()
        }
    }

    private fun fail(message: String) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putString(KEY_ERROR, message).apply()
        stopSelf()
    }

    private fun stopRecognition() {
        running.set(false)
        recorder?.let { try { it.stop() } catch (_: Exception) {} }
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
    }

    override fun onDestroy() { stopRecognition(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Studio song recognition", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Mor Ink Soundtrack is listening")
        .setContentText("Audio stays on this phone; a music fingerprint is sent for matching.")
        .setOngoing(true)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .build()

    companion object {
        const val ACTION_START = "com.morink.soundtrack.START_RECOGNITION"
        const val ACTION_STOP = "com.morink.soundtrack.STOP_RECOGNITION"
        const val KEY_RUNNING = "recognition_running"
        const val KEY_ERROR = "recognition_error"
        private const val CHANNEL_ID = "mor_ink_soundtrack_recognition"
        private const val NOTIFICATION_ID = 37
        private const val WINDOW_SECONDS = 12
        private const val POLL_INTERVAL_MS = 48_000L
        private const val SCHEDULE_CHECK_MS = 60_000L
    }
}
