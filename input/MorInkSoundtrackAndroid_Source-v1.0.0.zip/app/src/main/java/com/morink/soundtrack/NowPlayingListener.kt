package com.morink.soundtrack

import android.app.Notification
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.util.Locale
import java.util.concurrent.Executors

/** Captures song-identification notifications and reliably queues receiver failures. */
class NowPlayingListener : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val retryRunnable = object : Runnable {
        override fun run() {
            executor.execute { flushQueue() }
            mainHandler.postDelayed(this, RETRY_INTERVAL_MS)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        mainHandler.removeCallbacks(retryRunnable)
        mainHandler.post(retryRunnable)
        executor.execute { flushQueue() }
    }

    override fun onListenerDisconnected() {
        mainHandler.removeCallbacks(retryRunnable)
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(retryRunnable)
        executor.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        executor.execute { flushQueue() }
        if (!MainActivity.captureAllowed(this)) return
        val extras = sbn.notification.extras ?: return
        val packageName = sbn.packageName.lowercase(Locale.ROOT)
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val titleBig = extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()
        val infoText = extras.getCharSequence(Notification.EXTRA_INFO_TEXT)?.toString()?.trim().orEmpty()
        val combined = listOf(title, titleBig, text, bigText, subText, infoText)
            .filter { it.isNotBlank() }.joinToString(" — ")

        val isShazam = packageName == "com.shazam.android" || packageName.contains("shazam")
        val looksLikeMusic = isShazam ||
            packageName == "com.google.intelligence.sense" ||
            packageName == "com.google.android.as" ||
            packageName.contains("ambient") || packageName.contains("music") ||
            (packageName.contains("google") &&
                (combined.contains("now playing", true) || combined.contains("identified", true)))
        if (!looksLikeMusic || combined.length < 3) return

        val pair = mediaSessionSong(extras)
            ?: parseSong(title, titleBig, text, bigText, subText, infoText)
            ?: return

        val playedAt = Instant.ofEpochMilli(sbn.postTime).toString()
        val key = "${pair.first.lowercase(Locale.ROOT)}|${pair.second.lowercase(Locale.ROOT)}"
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val lastAt = prefs.getLong("last_song_seen_at", 0L)
        if (prefs.getString(MainActivity.KEY_LAST_KEY, "") == key &&
            sbn.postTime >= lastAt && sbn.postTime - lastAt < DUPLICATE_WINDOW_MS) return

        val eventId = "${sbn.postTime}-${key.hashCode()}"
        prefs.edit().putString(MainActivity.KEY_LAST_KEY, key)
            .putLong("last_song_seen_at", sbn.postTime)
            .putString(MainActivity.KEY_LAST_SONG, "${pair.first} — ${pair.second} · waiting to sync")
            .apply()

        val payload = JSONObject()
            .put("title", pair.first)
            .put("artist", pair.second)
            .put("playedAt", playedAt)
            .put("eventId", eventId)
            .put("studio", prefs.getString(MainActivity.KEY_STUDIO, "Mor Ink Shop"))
            .put("source", if (isShazam) "shazam-notification-listener" else "pixel-notification-listener")

        synchronized(this) {
            val old = try { JSONArray(prefs.getString(MainActivity.KEY_HISTORY, "[]") ?: "[]") }
                catch (_: Exception) { JSONArray() }
            val exists = (0 until old.length()).any { old.optJSONObject(it)?.optString("eventId") == eventId }
            if (!exists) old.put(JSONObject(payload.toString()))
            val trimmed = JSONArray()
            for (i in maxOf(0, old.length() - 2000) until old.length()) trimmed.put(old.get(i))
            prefs.edit().putString(MainActivity.KEY_HISTORY, trimmed.toString()).apply()
        }
        executor.execute { sendOrQueue(payload) }
    }

    private fun mediaSessionSong(extras: android.os.Bundle): Pair<String, String>? {
        return try {
            @Suppress("DEPRECATION")
            val token = extras.getParcelable(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token
                ?: return null
            val metadata = MediaController(this, token).metadata ?: return null
            val track = metadata.getString(MediaMetadata.METADATA_KEY_TITLE)?.trim().orEmpty()
            val artist = (metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST))?.trim().orEmpty()
            validTrackPair(track, artist)
        } catch (_: Exception) { null }
    }

    private fun parseSong(vararg rawFields: String): Pair<String, String>? {
        val fields = rawFields.map { it.trim() }.filter { it.isNotBlank() }
        for (candidate in fields) {
            for (separator in listOf(" — ", " - ", " • ", " by ")) {
                if (!candidate.contains(separator)) continue
                val parts = candidate.split(separator, limit = 2).map { it.trim() }
                if (parts.size == 2) validTrackPair(parts[0], parts[1])?.let { return it }
            }
        }
        // Shazam commonly displays track and artist in separate notification fields.
        val meaningful = fields.filterNot { isPlaceholderTitle(it) }
        for (track in meaningful) for (artist in meaningful) {
            if (track != artist) validTrackPair(track, artist)?.let { return it }
        }
        return null
    }

    private fun validTrackPair(trackRaw: String, artistRaw: String): Pair<String, String>? {
        val track = trackRaw.trim().trim('—', '-', '•', ':', ' ')
        val artist = artistRaw.trim().trim('—', '-', '•', ':', ' ')
        if (track.isBlank() || artist.isBlank() || track.equals(artist, true)) return null
        if (track.length > 120 || artist.length > 120) return null
        if (isPlaceholderTitle(track) || isPlaceholderTitle(artist)) return null
        return track to artist
    }

    private fun isPlaceholderTitle(value: String): Boolean {
        val normalized = value.trim().lowercase(Locale.ROOT).replace(Regex("[.…]+$"), "").trim()
        return normalized.isBlank() || normalized in setOf(
            "now playing", "identified", "song identified", "music identified", "song detected",
            "listening", "listening now", "unknown", "unknown song", "no song title", "playing music",
            "auto shazam", "auto shazam is on", "shazam"
        ) || normalized.startsWith("now playing ") || normalized.startsWith("listening to ")
    }

    private data class UploadResult(val success: Boolean, val code: Int?, val detail: String)

    private fun sendOrQueue(payload: JSONObject) {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val endpoint = prefs.getString(MainActivity.KEY_ENDPOINT, "").orEmpty()
        val secret = prefs.getString(MainActivity.KEY_SECRET, "").orEmpty()
        if (endpoint.isBlank() || secret.isBlank()) {
            appendQueue(payload, "Receiver URL or secret is missing")
            return
        }
        val result = postPayload(endpoint, secret, payload)
        recordResult(payload, result)
        if (result.success) {
            prefs.edit().putString(MainActivity.KEY_LAST_SONG,
                "${payload.optString("title")} — ${payload.optString("artist")} · accepted by receiver (${result.code})")
                .apply()
        } else appendQueue(payload, result.detail)
    }

    private fun flushQueue() {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val endpoint = prefs.getString(MainActivity.KEY_ENDPOINT, "").orEmpty()
        val secret = prefs.getString(MainActivity.KEY_SECRET, "").orEmpty()
        if (endpoint.isBlank() || secret.isBlank()) return
        val queue = try { JSONArray(prefs.getString(PENDING_QUEUE, "[]") ?: "[]") }
            catch (_: Exception) { JSONArray() }
        if (queue.length() == 0) return
        val remaining = JSONArray()
        for (i in 0 until queue.length()) {
            val item = queue.optJSONObject(i) ?: continue
            val result = postPayload(endpoint, secret, item)
            recordResult(item, result)
            if (!result.success) remaining.put(item)
            else prefs.edit().putString(MainActivity.KEY_LAST_SONG,
                "${item.optString("title")} — ${item.optString("artist")} · accepted by receiver (${result.code})").apply()
        }
        prefs.edit().putString(PENDING_QUEUE, remaining.toString()).apply()
    }

    private fun postPayload(endpoint: String, secret: String, payload: JSONObject): UploadResult {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10000
                readTimeout = 10000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json, text/plain, */*")
                setRequestProperty("x-shop-secret", secret)
            }
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = try { stream?.bufferedReader()?.use { it.readText() }.orEmpty() }
                catch (_: Exception) { "" }
            // Keep diagnostics short and secret-free; never store request headers or credentials.
            val detail = "HTTP $code" + if (response.isNotBlank()) ": ${response.take(220).replace(Regex("[\\r\\n\\t]+"), " ")}" else ""
            UploadResult(code in 200..299, code, detail)
        } catch (e: Exception) {
            UploadResult(false, null, "${e.javaClass.simpleName}: ${e.message.orEmpty().take(160)}")
        } finally { connection?.disconnect() }
    }

    private fun recordResult(payload: JSONObject, result: UploadResult) {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_UPLOAD_DIAGNOSTIC, result.detail.take(260))
            .putLong(KEY_UPLOAD_TIME, System.currentTimeMillis())
            .putInt(KEY_UPLOAD_CODE, result.code ?: -1).apply()
    }

    private fun appendQueue(payload: JSONObject, detail: String) {
        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        synchronized(this) {
            val queue = try { JSONArray(prefs.getString(PENDING_QUEUE, "[]") ?: "[]") }
                catch (_: Exception) { JSONArray() }
            val id = payload.optString("eventId")
            val exists = (0 until queue.length()).any { queue.optJSONObject(it)?.optString("eventId") == id }
            if (!exists && queue.length() < MAX_QUEUE) queue.put(JSONObject(payload.toString()))
            prefs.edit().putString(PENDING_QUEUE, queue.toString())
                .putString(MainActivity.KEY_LAST_SONG,
                    "${payload.optString("title")} — ${payload.optString("artist")} · queued")
                .putString(KEY_UPLOAD_DIAGNOSTIC, detail.take(260))
                .putLong(KEY_UPLOAD_TIME, System.currentTimeMillis()).apply()
        }
    }

    companion object {
        const val PENDING_QUEUE = "pending_queue"
        const val KEY_UPLOAD_DIAGNOSTIC = "upload_diagnostic"
        const val KEY_UPLOAD_TIME = "upload_time"
        const val KEY_UPLOAD_CODE = "upload_code"
        private const val RETRY_INTERVAL_MS = 60_000L
        private const val DUPLICATE_WINDOW_MS = 120_000L
        private const val MAX_QUEUE = 3000
    }
}
